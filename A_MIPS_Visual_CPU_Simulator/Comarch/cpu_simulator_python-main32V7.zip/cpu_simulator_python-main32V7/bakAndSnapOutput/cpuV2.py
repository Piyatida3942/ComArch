#cpu.py 
#simulates a simple CPU

from isa import Instruction

class CPU:
    def __init__(self, instructions, memory):
        """
        instructions: list of instruction strings
        memory: Memory object
        """

        self.PC = 0 
        self.registers = [0] * 32 
        self.memory = memory
        self.running = True

        # Parse instructions into Instruction objects
        self.instructions = [
            Instruction(line) for line in instructions
        ]

    def fetch(self):
        """
        Fetch the next instruction using PC
        """

        if self.PC >= len(self.instructions):
            self.running = False 
            return None

        instr = self.instructions[self.PC]
        
        return instr 
    
    def pc2hex(self):
        strpc = ('0'*7+hex(self.PC*4)[2:])[-8:]
        return strpc.upper()

    def run(self):
        """
        Main fetch-decode-execute loop
        """
        while self.running:
            instr = self.fetch()
            instr.decode2()
            if instr is None:
                break
            print(f"Executed: {self.pc2hex()} {instr.raw}")
            self.execute(instr)
            

            # Debug output uncomment below
            self.debug()
            
            self.PC += 1
        #Show register after finish
        print("Last STATE")
        self.debug()

    def debug(self):
        print(f"Registers:")
        for i in range(len(self.registers)):
            if i%8==0: print(f"{i:>2}-{i+7:>2}", end="")
            print(f"{self.registers[i]:>6}",end="")
            if i%8==7: print()
        print(f"-" * 80)
        self.memory.dump()
        print(f"-" * 80)


    def execute(self, instr):
        """
        Execute a single instruction 
        """
        opcode = instr.opcode
        ops = instr.operands
        # ADD rd, rs, rt        # Adds the values in register rs and rt and stores the result in rd
        if opcode == "ADD":
            rd,rs,rt = ops[0], ops[1], ops[3]
            self.registers[rd] = self.registers[rs] + self.registers[rt]
        # ADDI rt, rs, immediate # Adds an immediate value to the value in register rs and store the result in rt 
        elif opcode == "ADDI":
            rt, rs, imm = ops[0], ops[1], ops[2]
            self.registers[rt] = self.registers[rs] + imm

        # SW rt, offset(rs)     # Stores the value form register rt into memory at address (rs + offset)
        elif opcode == "SW":
            rt, rs, offset = ops[0], ops[1], ops[2]
            address = self.registers[rs] + offset
            value = self.registers[rt]
            self.memory.write(address, value)

        # LW rt, offset(rs)     # Loads a value from memroy at addres (rs + offset) into register rt
        elif opcode == "LW":
            rt, rs, offset = ops[0], ops[1], ops[2]
            address = self.registers[rs] + offset
            self.registers[rt] = self.memory.read(address)    

        # BEQ rs, rt, offset
        # If the values in registers rs and rt are equal,
        # branch to a new instruction by modifyin the PC    
        elif opcode == "BEQ":
            rt, rs, offset = ops[0], ops[1], ops[2]

            # Compare registers and update PC if equal 
            if self.registers[rs] == self.registers[rt]:
                self.PC += offset
                print(f"BEQ check: R{rs}={self.registers[rs]} R{rt}={self.registers[rt]}")

        # BNE rs, rt, offset
        # If the values in registers rs and rt are not equal,
        # branch to a new instruction by modifyin the PC    
        elif opcode == "BNE":
            rt, rs, offset = ops[0], ops[1], ops[2]

            # Compare registers and update PC if equal 
            if self.registers[rs] != self.registers[rt]:
                self.PC += offset
                print(f"BNE check: R{rs}={self.registers[rs]} R{rt}={self.registers[rt]}")

        # HALT
        # Stops CPU execution
        elif opcode  == "HALT":
            self.running = False  
