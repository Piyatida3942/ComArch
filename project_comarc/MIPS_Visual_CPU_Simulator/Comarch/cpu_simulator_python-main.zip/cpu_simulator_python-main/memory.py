#memory.py
#simualates main memory for the CPU

class Memory:
    def __init__(self):
        #Dictionary to store memory values
        #Key -> address
        #value -> data stored at that address
        self.data = {}

    def read(self, address):
        """
        Return tha value at a given memory address.
        If the address has never been written to,
        return 0 (default memory behavior).
        """
        return self.data.get(address, 0)
    
    def write(self, address, value):
        """
        write a value to a given memory address.
        """
        self.data[address] = value 





    
