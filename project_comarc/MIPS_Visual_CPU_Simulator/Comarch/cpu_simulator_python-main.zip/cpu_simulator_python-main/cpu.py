#cpu.py 
#simulates a simple CPU

from isa import Instruction 

class CPU:
    def __init__(self, instructions, memory):
        """
        instructions: list of instruction strings
        memory: Memory object
        """

        self.PC = 0 
        self.registers = [0] * 8 
        self.memory = memory
        self.running = True

        # Parse instructions into Instruction objects
        self.instructions = [
            Instruction(line) for line in instructions
        ]

    def fetch(self):
        """
        Fetch the next instruction using PC
        """

        if self.PC >= len(self.instructions):
            self.running = False 
            return None

        instr = self.instructions[self.PC]
        self.PC += 1
        return instr 
    
    def execute(self, instr):
        """
        Execute a single instruction 
        """
        opcode = instr.opcode
        ops = instr.operands

        # ADD rd, rs, rt
        # Adds the values in register rs and rt and stores the result in rd
        if opcode == "ADD":
            rd = int(ops[0][1]) # Destination register
            rs = int(ops[1][1]) # First source register
            rt = int(ops[2][1]) # Second source register

            self.registers[rd] = self.registers[rs] + self.registers[rt]
        
        # ADDI rt, rs, immediate
        # Adds an immediate value to the value in register rs and store the result in rt 
        elif opcode == "ADDI":
            rt = int(ops[0][1]) # Destination register
            rs = int(ops[1][1]) # Source register
            imm = int(ops[2])   # Immediate value

            self.registers[rt] = self.registers[rs] + imm

        # SW rt, offset(rs)    
        # Stores the value form register rt into memory at address (rs + offset)
        elif opcode == "SW":
            rt = int(ops[0][1]) # Register conatainin the value to store
            offset_reg = ops[1] # Format: offset(rs)

            offset = int(offset_reg.split("(")[0])
            rs = int(offset_reg.split("(")[1][1])

            address = self.registers[rs] + offset
            value = self.registers[rt]

            self.memory.write(address, value)

        # LW rt, offset(rs)
        # Loads a valur from memroy at addres (rs + offset) into register rt
        elif opcode == "LW":
            rt = int(ops[0][1]) # Destination register 
            offset_reg = ops[1] # Format: offset(rs)

            offset = int(offset_reg.split("(")[0])
            rs = int(offset_reg.split("(")[1][1])

            address = self.registers[rs] + offset
            self.registers[rt] = self.memory.read(address)    

        # BEQ rs, rt, offset
        # If the values in registers rs and rt are equal,
        # branch to a new instruction by modifyin the PC    
        elif opcode == "BEQ":
            rs = int(ops[0][1]) # First source register 
            rt = int(ops[1][1]) # Second source register
            offset = int(ops[2]) # Number of instructions to jump

            # Compare registers and update PC if equal 
            if self.registers[rs] == self.registers[rt]:
                self.PC += offset
                print(f"BEQ check: R{rs}={self.registers[rs]} R{rt}={self.registers[rt]}")

        # HALT
        # Stops CPU execution
        elif opcode  == "HALT":
            self.running = False  

    def run(self):
        """
        Main fetch-decode-execute loop
        """
        while self.running:
            instr = self.fetch()
            if instr is None:
                break
            self.execute(instr)
            

            # Debug output
            print(f"Executed: {instr.raw}")
            print(f"Registers: {self.registers}")
            print(f"-" * 40)


