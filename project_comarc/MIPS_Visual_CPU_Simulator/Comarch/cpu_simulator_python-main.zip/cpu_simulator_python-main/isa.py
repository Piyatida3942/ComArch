# isa.py 
# Handles instruction parsing and decoding 

class Instruction:
    def __init__(self, raw_line):
        """
        raw_line a single line from the instruction file
        Example: "ADD R1 R2 R3"
        """

        self.raw =  raw_line.strip()
        self.opcode = None 
        self.operands = []

        self.decode()

    def decode(self):
        """
        Split the instrucion into opcode and operands
        """

        if not self.raw:
            return
        
        parts = self.raw.split()
        self.opcode = parts[0]
        self.operands = parts[1:]






